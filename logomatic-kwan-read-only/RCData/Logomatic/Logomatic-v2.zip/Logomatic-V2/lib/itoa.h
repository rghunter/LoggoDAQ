int itoa(int n, int b, char str[]);
int convert(int n, int b, char str[], int i);
