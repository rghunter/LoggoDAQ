

extern void UART1_Init(unsigned int baudrate);
extern void UART1_Send(unsigned char *buf, unsigned int len);
