#include <LPC2103.H> 

#include "main.h"

#define DMX_NR  368                        // My own DMX slave numer

//void SetOutReport(unsigned char *rep)          // OutReport received from USB host
//{
//    IOPIN = (IOPIN & 0xFF00FFFF) | (DMX_buf[1] << 16);
//}


//const unsigned long CRP __at(0x1FC);
const unsigned long CRP __attribute__((at(0x1FC))) = 0xFFFFFFFF;


int main (void)
{
    UART1_Init(250000);
    T1_Init();
	    
	IODIR |= 0x00FF0000;                   // LEDs at P0.16 - 23
	IOCLR |= 0x00FF0000;                   // turn LEDs off

    while(1)
    {
        if (f_200ms)
        {
            f_200ms = 0;
            IOPIN = (IOPIN & 0xFF00FFFF) | (DMX_buf[DMX_NR] << 16);

        }
    }
}
