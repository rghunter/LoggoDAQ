#include <LPC2103.H>

#include "uart1.h"

unsigned char DMX_buf[512];


void DMX_SendPacket(void)
{
    UART1_Send(DMX_buf,512);    // send data packet to slaves
}

void DMX_Init(void)
{
  int i;

    for (i = 0; i < 512; i++)
        DMX_buf[i] = 'a';

	IODIR |= 0x00000080;                      // P0.7 = DS75176 enable
	IOCLR |= 0x00000080;                      // low active

    UART1_Init(250000);
}
