
extern void T1_Init(void);
extern char f_10ms;
extern char f_200ms;

extern unsigned char DMX_buf[513];
extern void UART1_Init(unsigned int baudrate);
