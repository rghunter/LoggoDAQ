

#define ST_MBB    0        // state "mark before break"
#define ST_SFB    1        // state "space for break"
#define ST_MAB    2        // state "mark after break"
#define ST_TXD    3        // state "transmit data"
