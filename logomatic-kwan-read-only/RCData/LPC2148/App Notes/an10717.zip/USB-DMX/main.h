
extern void T1_Init(void);
extern char f_10ms;
extern char f_200ms;

extern void GetInReport(BYTE *rep);
extern void SetOutReport(BYTE *rep);
extern void USB_Init(void);
extern void USB_Connect(BOOL con);

extern void DMX_Init(void);
extern void DMX_SendPacket(void);

extern unsigned char DMX_buf[16];

extern void UART1_Send(unsigned char *buf, unsigned int len);

