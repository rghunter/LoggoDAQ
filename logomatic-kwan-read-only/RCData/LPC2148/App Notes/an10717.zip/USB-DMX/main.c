#include <LPC214x.H> 

#include "type.h"
#include "main.h"


extern void ua_outchar(char c);


void GetInReport(unsigned char *rep)           // Host is asking for an InReport
{
    rep[0] = 55;
}

void SetOutReport(unsigned char *rep)          // OutReport received from USB host
{
  unsigned short i;

    i = (rep[0] * 100) + rep[1];               // USB received desired lamp status
    DMX_buf[i] = rep[2];

//    IOPIN1 = (IOPIN1 & 0xFF00FFFF) | (rep[2] << 16);
}

int main (void)
{
//  char i;

    USB_Init();                                // USB Initialization
    USB_Connect(TRUE);                         // USB Connect
    DMX_Init();
    T1_Init();
	    
//	IODIR1 |= 0x00FF0000;                      // LEDs at P1.16 - 23
//	IOCLR1 |= 0x00FF0000;                      // turn LEDs off

//    UART1_Send("\fHello magnificent world of the LPC2000 !\r\n",43);

	
    while(1)
    {
        if (f_200ms)
        {
            f_200ms = 0;


//            if (U1LSR & 1)
//            {
//                i = U1RBR & 0x7F;       // yes, return character from input buffer

                DMX_SendPacket();                  // DMX send data to slaves
//            }
        }
    }
}
