
#include <LPC214x.h>

// motorCurrent measured at AIN0.4 (P0.25)


void ADC0_Init(void)
{
// ADC setup:
// Bit 0 - 7   (SEL)     : 0x0000 0010      Scan AIN4
// Bit 8 - 15  (CLKDIV)  : 0x0000 0F00      AD scanrate at 60MHz/(15+1) = 3.75MHz
// Bit 16      (BURST)   : 0x0000 0000      sw start / burst mode
// Bit 17 - 19 (CLKS)    : 0x0000 0000      10-bit resolution
// Bit 20                : 0x0000 0000      reserved
// Bit 21      (PDN)     : 0x0020 0000      Power up AD converter
// Bit 22 - 23           : 0x0000 0000      reserved
// Bit 24 - 26 (START)   : 0x0000 0000      No start (yet)
// Bit 27      (EDGE)    : 0x0000 0000      Not used in burst mode
// Bit 28 - 31           : 0x0000 0000      reserved

    PINSEL1 |= 0x00040000;         // P0.25 = AIN0.4
    AD0CR    = 0x00200F10;         // initialise ADC0, select AIN4
    AD0CR   |= 0x00010000;         // start burst mode now, see errata ADC.2
}
