
#define MAX_Im         0xF0            // max motor current limit

extern unsigned char actualSpeed;

extern void GetInReport(unsigned char *rep);
extern void SetOutReport(unsigned char *rep);
extern void USB_Init(void);
extern void USB_Connect(unsigned int con);

extern void ADC0_Init(void);
extern void PWM_Init(void);
extern void HES_Init(void);

extern void T1_Init(void);
extern char f_10ms;
