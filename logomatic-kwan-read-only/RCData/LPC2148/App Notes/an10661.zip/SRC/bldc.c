
#include <LPC214x.H>                           // LPC214x definitions
#include "bldc.h"


unsigned char actualSpeed  = 0;
unsigned char desiredSpeed = 0;
unsigned int  RPM,fRPM;


void GetInReport(unsigned char *rep)           // Host is asking for an InReport
{
    rep[0] = fRPM;                             // send measured motor speed (low byte)
    rep[1] = fRPM >> 8;                        // send measured motor speed (high byte)
    rep[2] = AD0DR4 >> 8;;                     // send potm value for debugging
}

void SetOutReport(unsigned char *rep)          // OutReport received from USB host
{
    if (rep[0] < 101)
        desiredSpeed = rep[0];
}

int main (void)
{
    IO1DIR |= 0x00070000;                      // 3 LED table: P1.16, P1.17 and P1.18
    IO1CLR  = 0x00070000;                      // Turn them all Off

    ADC0_Init();                               // ADC0 Initialization
    T1_Init();                                 // 10 msec tick
    PWM_Init();                                // PWM Timer Initialization
    HES_Init();
    USB_Init();                                // USB Initialization
    USB_Connect(1);                            // USB Connect

    while (1)                                  // Loop forever
    {
        if (((AD0DR4 >> 8) & 0xFF) > MAX_Im)   // Check motor overcurrent
        {
            VICIntEnClr = 0xFFFFFFFF;          // disable all interrupts!
            PWMMR1 = 0;                        // Q1 off
            PWMMR2 = 0;                        // Q2 off
            PWMMR3 = 0;                        // Q3 off
            PWMMR4 = 0;                        // Q4 off
            PWMMR5 = 0;                        // Q5 off
            PWMMR6 = 0;                        // Q6 off
            PWMLER = 0x7F;                     // enable PWM0 - PWM6 match latch (reload)
            while (1) ;                        // wait for a RESET
        }

        if (f_10ms)                            // every 10 mseconds
        {
            f_10ms = 0;

            if (actualSpeed > desiredSpeed)
                actualSpeed --;
            else if (actualSpeed < desiredSpeed)
                actualSpeed ++;

            RPM = 10000000 / T0CR0;            // calculate motor speed
            fRPM = ((fRPM * 15) + RPM) / 16;   // filter it
        }
    }
}
