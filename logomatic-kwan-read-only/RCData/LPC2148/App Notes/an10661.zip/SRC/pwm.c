#include <LPC214x.h>

void PWM_Init(void)
{
    PINSEL0 |= 0x000A800A;         // select PWM1-4 and PWM6
    PINSEL1 |= 0x00000400;         // select PWM5

    PWMPR = 20;                    // prescaler to 20, timer runs at 60 MHz / 20 = 3 MHz
    PWMPC = 0;                     // prescale counter to 0
    PWMTC = 0;                     // reset timer to 0
  
    PWMMR0 = 100;                  // -> PMW base frequency = 3 MHz / 100 = 30 KHz
    PWMMR1 = 0;                    // Match 1 for Q1 (off)
    PWMMR2 = 0;                    // Match 2 for Q2 (off)
    PWMMR3 = 0;                    // Match 3 for Q3 (off)
    PWMMR4 = 0;                    // Match 4 for Q4 (off)
    PWMMR5 = 0;                    // Match 5 for Q5 (off)
    PWMMR6 = 0;                    // Match 6 for Q6 (off)
 
    PWMMCR = 0x00000002;           // reset TC on MR0
    PWMPCR = 0x7E00;               // enable PWM1 - PWM6 outputs
    PWMLER = 0x7F;                 // enable PWM0 - PWM6 match latch (reload)

    PWMTCR = 0x09;                 // enable PWM mode and start timer
}
