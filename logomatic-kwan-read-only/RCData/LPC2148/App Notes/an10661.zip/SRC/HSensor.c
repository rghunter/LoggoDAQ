#include <LPC214x.H>                   // LPC214x definitions
#include "bldc.h"


__irq void T0_Isr(void)
{
    T0TC = 0;                          // Reset timer

    switch ((IO0PIN >> 18) & 7)        // read Hall sensor inputs P0.18, P0.19 and P0.20
    {			
      case 1:  PWMMR1 = actualSpeed;   // phase 6: 001
               PWMMR2 = 0;
               PWMMR3 = 0;
               PWMMR4 = 0;
               PWMMR5 = 0;
               PWMMR6 = actualSpeed;
               break;
      case 2:  PWMMR1 = 0;             // phase 4: 010
               PWMMR2 = actualSpeed;
               PWMMR3 = 0;
               PWMMR4 = actualSpeed;
               PWMMR5 = 0;
               PWMMR6 = 0;
               break;
      case 3:  PWMMR1 = 0;             // phase 5: 011
               PWMMR2 = actualSpeed;
               PWMMR3 = 0;
               PWMMR4 = 0;
               PWMMR5 = 0;
               PWMMR6 = actualSpeed;
               break;
      case 4:  PWMMR1 = 0;             // phase 2: 100
               PWMMR2 = 0;
               PWMMR3 = actualSpeed;
               PWMMR4 = 0;
               PWMMR5 = actualSpeed;
               PWMMR6 = 0;
               break;
      case 5:  PWMMR1 = actualSpeed;   // phase 1: 101
               PWMMR2 = 0;
               PWMMR3 = 0;
               PWMMR4 = 0;
               PWMMR5 = actualSpeed;
               PWMMR6 = 0;
               break;
      case 6:  PWMMR1 = 0;             // phase 3: 110
               PWMMR2 = 0;
               PWMMR3 = actualSpeed;
               PWMMR4 = actualSpeed;
               PWMMR5 = 0;
               PWMMR6 = 0;
               break;
      default: break;                  // invalid
    }

    T0IR = 0xFF;                       // reset flags
    PWMLER = 0x7F;                     // enable PWM0 - PWM6 match latch (reload)
    VICVectAddr = 0;                   // Acknowledge interrupt by reseting VIC
}

void HES_Init(void)
{
    VICVectAddr1  = (unsigned int) &T0_Isr;
    VICVectCntl1  = 0x24;              // Channel1 on Source#4 ... enabled
    VICIntEnable |= 0x10;              // Channel#4 is the Timer 0

    PINSEL1 |= 0x3A000000;             // P0.30, P0.28 and P0.29 as CAP0.0, CAP0.2 and CAP0.3

    T0PR  = 60;                        // prescaler 60, timer runs at 60 MHz / 60 = 1 MHz
    T0MR0 = 1000000;                   // = 1 sec / 1 us
    T0MCR = 3;
    T0CCR = 0x0FC7;                    // Capture on both edges and enable the interrupt
    T0TC  = 0;                         // Reset timer
    T0TCR = 1;                         // start timer
} 

