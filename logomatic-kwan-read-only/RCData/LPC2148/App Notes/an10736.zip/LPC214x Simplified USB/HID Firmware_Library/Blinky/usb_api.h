/***************************************** 
 ****** API Specific declarations ******** 
 *****************************************/

typedef void (*PFV)();

/* These two functions are defined in HID.lib */
extern void  USB_Init(PFV, PFV);
extern void  USB_Connect(BOOL);

/* This should be set by the user according to usbcfg.h */
#define USB_HID_REPORT_IN   1
#define USB_HID_REPORT_OUT   1

/* All the data that come from the host gets accumulated in OutReport[]
   All the data that needs to go the host should get accumulated in InReport[] */
extern BYTE InReport[USB_HID_REPORT_IN];
extern BYTE OutReport[USB_HID_REPORT_OUT];

