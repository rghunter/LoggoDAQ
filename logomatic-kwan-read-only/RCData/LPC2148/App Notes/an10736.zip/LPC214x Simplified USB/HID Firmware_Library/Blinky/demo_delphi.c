/*----------------------------------------------------------------------------
 *      Name:    DEMO.C
 *      Purpose: USB HID Demo
 *      Version: V1.10
 *----------------------------------------------------------------------------
 *      This software is supplied "AS IS" without any warranties, express,
 *      implied or statutory, including but not limited to the implied
 *      warranties of fitness for purpose, satisfactory quality and
 *      noninfringement. Keil extends you a royalty-free right to reproduce
 *      and distribute executable files created using this software for use
 *      on Philips LPC microcontroller devices only. Nothing else gives you
 *      the right to use this software.
 *
 *      Copyright (c) 2005-2006 Keil Software.
 *---------------------------------------------------------------------------*/

#include <LPC214X.H>                        /* LPC214x definitions */
#include "type.h"
#include "usb_api.h"
#include "demo.h"



/*
 *  Get HID Input Report -> InReport. This function should be 
 * defined by the user
 */

void GetInReport (void) {

  if ((IOPIN0 & PBINT) == 0) {              /* Check if PBINT is pressed */
    InReport[0] = 0x01;
  } else {
    InReport[0] = 0x00;
  }
}



/*
 *  Set HID Output Report <- OutReport. This function should be 
 * defined by the user
 */

void SetOutReport (void) {
   IOPIN1 = (IOPIN1 & ~LEDMSK) | (OutReport[0] << 16);
  
}


/* Main Program */

int main (void) {
  
  IODIR1 = LEDMSK;                          /* LED's defined as Outputs */
  IOPIN1 = 0xFF << 16;

  USB_Init(GetInReport,SetOutReport);       /* USB Initialization */
  USB_Connect(TRUE);
  
  while (1);                                /* Loop forever */
}
